package com.softschool.backend.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.softschool.backend.model.DropoutStaffRecord;
import com.softschool.backend.model.Finance;
import com.softschool.backend.model.Staff;
import com.softschool.backend.repository.DropoutStaffRecordRepository;
import com.softschool.backend.repository.FinanceRepository;
import com.softschool.backend.repository.StaffRepository;
import com.softschool.backend.service.PlanEnforcementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Every endpoint here is scoped by schoolId (School.schoolId, e.g. "SS_77_1")
 * so each school only ever sees and modifies its own staff — see
 * Staff.schoolId / the (schoolId, staffId) unique constraint on the entity.
 * The frontend (manage-staff.js) always sends the logged-in school's ID,
 * taken from the real session set up at login.
 */
@RestController
@RequestMapping("/api/staff")
@CrossOrigin(origins = "*")
public class StaffController {

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private PlanEnforcementService planEnforcementService;

    @Autowired
    private FinanceRepository financeRepository;

    @Autowired
    private DropoutStaffRecordRepository dropoutStaffRecordRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Staff staff) {
        if (isBlank(staff.getSchoolId())) {
            return badRequest("schoolId is required.");
        }
        if (isBlank(staff.getStaffId())) {
            return badRequest("staffId is required.");
        }

        // Handle Update logic: if staffId exists FOR THIS SCHOOL, reuse the
        // internal primary key so this is an update, not a duplicate insert —
        // scoped by schoolId too, so School A can never overwrite School B's
        // staff member just because they happen to share a staffId (e.g. same
        // prefix producing "PSC_S_1" for both).
        boolean isNew = staffRepository.findByStaffIdAndSchoolId(staff.getStaffId(), staff.getSchoolId())
                .map(existing -> {
                    staff.setId(existing.getId());
                    return false;
                })
                .orElse(true);

        // New hires count against staffLimit + the "staff" feature lock;
        // edits to an existing staff row don't change headcount, so they
        // only need the feature-lock check (Security Audit #2).
        if (isNew) {
            planEnforcementService.requireCapacityForNewStaff(staff.getSchoolId());
        } else {
            planEnforcementService.requireFeature(staff.getSchoolId(), PlanEnforcementService.FEATURE_STAFF);
        }

        Staff saved = staffRepository.save(staff);
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public ResponseEntity<?> getAll(@RequestParam(required = false) String schoolId) {
        if (isBlank(schoolId)) {
            return badRequest("schoolId query parameter is required.");
        }
        return ResponseEntity.ok(staffRepository.findBySchoolId(schoolId));
    }

    @DeleteMapping("/{staffId}")
    @Transactional
    public ResponseEntity<?> delete(@PathVariable String staffId, @RequestParam String schoolId) {
        if (isBlank(schoolId)) {
            return badRequest("schoolId query parameter is required.");
        }
        return staffRepository.findByStaffIdAndSchoolId(staffId, schoolId)
                .map(existing -> {
                    // BUGFIX — "deleted staff's paid salary/fines/advance
                    // stop showing up anywhere on the dashboard": every
                    // Finance row for this staffId is about to be wiped
                    // below (see the next comment for why), so capture a
                    // permanent snapshot of what was actually paid to this
                    // staff member FIRST — before any of that history is
                    // gone — and archive it as a DropoutStaffRecord. The
                    // dashboard's "Dropout Staff Paid Salary" card (GET
                    // /api/finance/dropout-staff) reads these archives back,
                    // so money paid to now-deleted staff keeps counting
                    // toward Net Expenses forever after, instead of
                    // disappearing the moment the staff row is removed.
                    archiveDropoutStaffSnapshot(existing, staffId, schoolId);

                    staffRepository.deleteById(existing.getId());

                    // BUGFIX — "delete a staff member, add a new one, and the
                    // new hire's salary shows Paid" / "add another after that
                    // and it flips to Pending":
                    //
                    // manage-staff.js's generateStaffId() always reuses the
                    // lowest free numeric suffix (e.g. delete staff #3, the
                    // next hire becomes #3 again), but this endpoint used to
                    // only delete the Staff row — every Finance row (SALARY,
                    // ADVANCE, and staff bonus/fine entries) stayed behind,
                    // still keyed by that same staffId. So the next hire who
                    // got id #3 reused would immediately "inherit" whatever
                    // salary/advance/bonus/fine history the deleted staff #3
                    // had (e.g. an already-Paid salary row for the current
                    // month), while the hire after that got a fresh, never
                    // reused id and correctly showed Pending. Wiping every
                    // finance record tied to this staffId here means a
                    // reused id always starts with a clean slate.
                    financeRepository.deleteByStaffIdAndSchoolId(staffId, schoolId);
                    purgeStaffFromBulkFinanceLists(staffId, schoolId);

                    return ResponseEntity.ok().build();
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    /**
     * Sums up everything this staff member was ever actually paid — every
     * SALARY row's amountPaid (all months), every still-outstanding ADVANCE
     * (paymentStatus != "Settled" — a settled advance is already folded
     * into a SALARY row's amountPaid, so counting it here too would double
     * it, mirroring how the live dashboard treats advances in main.js's
     * _dashboardAdvanceTotal), and every STAFF_BONUS entry on file for
     * them — plus their STAFF_FINE total, kept for record-keeping only
     * (a fine is a deduction, not a payout, so it's never added into
     * `total`). Only archives a record when there's actually something to
     * remember, so deleting a staff member with zero finance history never
     * clutters the dropout-staff list with a $0 row.
     */
    private void archiveDropoutStaffSnapshot(com.softschool.backend.model.Staff staff, String staffId, String schoolId) {
        double paidSalaryTotal = financeRepository
                .findByStaffIdAndRecordTypeAndSchoolIdOrderByCreatedAtDesc(staffId, Finance.TYPE_SALARY, schoolId)
                .stream()
                .mapToDouble(row -> {
                    if (row.getAmountPaid() != null) return row.getAmountPaid();
                    double netPaid = row.getNetPaid() != null ? row.getNetPaid() : 0.0;
                    double advanceDeducted = row.getAdvanceDeducted() != null ? row.getAdvanceDeducted() : 0.0;
                    return netPaid + advanceDeducted;
                })
                .sum();

        double advancePaidTotal = financeRepository
                .findByStaffIdAndRecordTypeAndSchoolIdOrderByCreatedAtDesc(staffId, Finance.TYPE_ADVANCE, schoolId)
                .stream()
                .filter(row -> !"Settled".equalsIgnoreCase(row.getPaymentStatus()))
                .mapToDouble(row -> row.getAmount() != null ? row.getAmount() : 0.0)
                .sum();

        double bonusPaidTotal = sumBulkFinanceAmountForStaff(Finance.TYPE_STAFF_BONUS, staffId, schoolId);
        double finesTotal = sumBulkFinanceAmountForStaff(Finance.TYPE_STAFF_FINE, staffId, schoolId);

        double total = paidSalaryTotal + advancePaidTotal + bonusPaidTotal;
        if (total <= 0.0 && finesTotal <= 0.0) {
            return;
        }

        DropoutStaffRecord record = new DropoutStaffRecord();
        record.setSchoolId(schoolId);
        record.setStaffId(staffId);
        record.setStaffName(staff.getName());
        record.setPaidSalaryTotal(paidSalaryTotal);
        record.setAdvancePaidTotal(advancePaidTotal);
        record.setBonusPaidTotal(bonusPaidTotal);
        record.setFinesTotal(finesTotal);
        record.setTotal(total);
        dropoutStaffRecordRepository.save(record);
    }

    /**
     * Sums the "amount" field embedded in payloadJson for every row of a
     * bulk-list recordType (STAFF_BONUS / STAFF_FINE) that belongs to this
     * staff member — same lookup rowBelongsToStaff() below already does for
     * purging, reused here to total them up before they're gone.
     */
    private double sumBulkFinanceAmountForStaff(String recordType, String staffId, String schoolId) {
        return financeRepository.findByRecordTypeAndSchoolIdOrderByCreatedAtAsc(recordType, schoolId)
                .stream()
                .filter(row -> rowBelongsToStaff(row, staffId))
                .mapToDouble(row -> {
                    try {
                        JsonNode node = objectMapper.readTree(row.getPayloadJson());
                        return node.hasNonNull("amount") ? node.get("amount").asDouble() : 0.0;
                    } catch (Exception e) {
                        return 0.0;
                    }
                })
                .sum();
    }

    /**
     * STAFF_BONUS / STAFF_FINE / STAFF_ADVANCE_BULK rows (see Finance.java)
     * don't carry a real staffId column — each row's staffId lives inside
     * its payloadJson blob instead (as "staffId", falling back to "id").
     * financeRepository.deleteByStaffIdAndSchoolId() can't reach those, so
     * walk each bucket here and drop any row whose embedded staffId/id
     * matches the staff member that was just deleted — otherwise a reused
     * staffId could still surface a dead staff member's old bonus/fine
     * entries once it's assigned to a new hire.
     */
    private void purgeStaffFromBulkFinanceLists(String staffId, String schoolId) {
        List<String> bulkTypes = List.of(
                Finance.TYPE_STAFF_BONUS,
                Finance.TYPE_STAFF_FINE,
                Finance.TYPE_STAFF_ADVANCE_BULK
        );
        for (String recordType : bulkTypes) {
            List<Finance> rows = financeRepository.findByRecordTypeAndSchoolIdOrderByCreatedAtAsc(recordType, schoolId);
            for (Finance row : rows) {
                if (rowBelongsToStaff(row, staffId)) {
                    financeRepository.delete(row);
                }
            }
        }
    }

    private boolean rowBelongsToStaff(Finance row, String staffId) {
        String payload = row.getPayloadJson();
        if (isBlank(payload)) return false;
        try {
            JsonNode node = objectMapper.readTree(payload);
            String embeddedStaffId = node.hasNonNull("staffId") ? node.get("staffId").asText()
                    : node.hasNonNull("id") ? node.get("id").asText() : null;
            return staffId.equals(embeddedStaffId);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private ResponseEntity<?> badRequest(String message) {
        return ResponseEntity.badRequest().body(errorBody(message));
    }

    private Map<String, String> errorBody(String message) {
        return Collections.singletonMap("error", message);
    }
}